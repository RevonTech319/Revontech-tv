import { initializeApp } from "firebase/app";
import { getFirestore, doc, getDoc } from "firebase/firestore";
import fs from 'fs';
import path from 'path';

// Parse .env manually
try {
  const envContent = fs.readFileSync(path.resolve('.env'), 'utf8');
  envContent.split('\n').forEach(line => {
    const match = line.match(/^\s*([\w.-]+)\s*=\s*(.*)?\s*$/);
    if (match) {
      const key = match[1];
      let value = match[2] || '';
      if (value.startsWith('"') && value.endsWith('"')) {
        value = value.substring(1, value.length - 1);
      } else if (value.startsWith("'") && value.endsWith("'")) {
        value = value.substring(1, value.length - 1);
      }
      process.env[key] = value;
    }
  });
} catch (e) {
  console.error("Could not load .env file", e);
}

const firebaseConfig = {
  apiKey: process.env.VITE_FIREBASE_API_KEY,
  authDomain: process.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: process.env.VITE_FIREBASE_PROJECT_ID,
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

async function testPalmPesa() {
  console.log("=== TESTING PALMPESA API ===");
  
  // 1. Fetch credentials
  let token = "";
  let userId = "";
  try {
    const settingsRef = doc(db, 'settings', 'general_settings');
    const settingsSnap = await getDoc(settingsRef);
    if (settingsSnap.exists()) {
      const data = settingsSnap.data();
      token = data.palmpesa_token || "";
      userId = data.palmpesa_user_id || "";
    }
  } catch (err) {
    console.error("Error reading credentials:", err);
    process.exit(1);
  }

  if (!token) {
    console.error("PalmPesa Token is empty in Firestore settings!");
    process.exit(1);
  }

  console.log("Using User ID:", userId);
  console.log("Using Token:", token);

  // 2. Fetch recent transactions from PalmPesa
  try {
    console.log("\nFetching recent transactions from PalmPesa...");
    const res = await fetch("https://palmpesa.drmlelwa.co.tz/api/transactions?page=1&per_page=10", {
      method: "GET",
      headers: {
        "Accept": "application/json",
        "Authorization": `Bearer ${token}`
      }
    });
    
    console.log("Response Status:", res.status);
    const data = await res.json();
    console.log("Response Body (Truncated/JSON):", JSON.stringify(data, null, 2));
  } catch (err) {
    console.error("Error calling transactions API:", err);
  }

  process.exit(0);
}

testPalmPesa();
