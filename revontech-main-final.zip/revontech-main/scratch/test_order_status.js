import { initializeApp } from "firebase/app";
import { getFirestore, doc, getDoc } from "firebase/firestore";
import fs from 'fs';
import path from 'path';

// Parse .env manually
try {
  const envContent = fs.readFileSync(path.resolve('.env'), 'utf8');
  envContent.split('\n').forEach(line => {
    const match = line.match(/^\s*([\w.-]+)\s*=\s*(.*)?\s*$/);
    if (match) {
      const key = match[1];
      let value = match[2] || '';
      if (value.startsWith('"') && value.endsWith('"')) {
        value = value.substring(1, value.length - 1);
      } else if (value.startsWith("'") && value.endsWith("'")) {
        value = value.substring(1, value.length - 1);
      }
      process.env[key] = value;
    }
  });
} catch (e) {
  console.error("Could not load .env file", e);
}

const firebaseConfig = {
  apiKey: process.env.VITE_FIREBASE_API_KEY,
  authDomain: process.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: process.env.VITE_FIREBASE_PROJECT_ID,
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

async function testOrderStatus() {
  console.log("=== TESTING PALMPESA ORDER STATUS ===");
  
  // 1. Fetch credentials
  let token = "";
  try {
    const settingsRef = doc(db, 'settings', 'general_settings');
    const settingsSnap = await getDoc(settingsRef);
    if (settingsSnap.exists()) {
      token = settingsSnap.data().palmpesa_token || "";
    }
  } catch (err) {
    console.error("Error reading credentials:", err);
    process.exit(1);
  }

  if (!token) {
    console.error("PalmPesa Token is empty!");
    process.exit(1);
  }

  // 2. Call order status with order_id and reference
  const orderId = "PALMPESA17791201191115";
  const ref = "RT_1779120115602";
  
  try {
    console.log(`Querying order-status with order_id: ${orderId} and reference: ${ref}...`);
    const res = await fetch("https://palmpesa.drmlelwa.co.tz/api/order-status", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "Authorization": `Bearer ${token}`
      },
      body: JSON.stringify({
        order_id: orderId,
        reference: ref
      })
    });
    
    console.log("Response Status:", res.status);
    const data = await res.json();
    console.log("Response Body:", JSON.stringify(data, null, 2));
  } catch (err) {
    console.error("Error calling order status:", err);
  }

  process.exit(0);
}

testOrderStatus();
