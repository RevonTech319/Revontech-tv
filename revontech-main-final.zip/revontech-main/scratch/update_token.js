import { initializeApp } from 'firebase/app';
import { getFirestore, collection, getDocs, addDoc, serverTimestamp, query, orderBy, limit } from 'firebase/firestore';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import { readFileSync, existsSync } from 'fs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Try multiple possible paths for .env
const possiblePaths = [
  join(__dirname, '../.env'),
  join(__dirname, '../../.env'),
  join(process.cwd(), '.env')
];

let envPath = '';
for (const p of possiblePaths) {
  if (existsSync(p)) {
    envPath = p;
    break;
  }
}

if (!envPath) {
  console.error("Could not find .env file");
  process.exit(1);
}

const envContent = readFileSync(envPath, 'utf8');
const env = {};
envContent.split('\n').forEach(line => {
  const [key, ...valueParts] = line.split('=');
  const value = valueParts.join('=');
  if (key && value) {
    env[key.trim()] = value.trim().replace(/^"(.*)"$/, '$1');
  }
});

const firebaseConfig = {
  apiKey: env.VITE_FIREBASE_API_KEY,
  authDomain: env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: env.VITE_FIREBASE_APP_ID
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

const NEW_TOKEN = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJleHAiOjE3Nzc4NDUwMjgsInNpcCI6IjMuMTcyLjUuNDcifQ.snuae7n7AChoZmOaWPh-Pd4RdyC40ZGkbyXi5rmyu1smaFnKHwSaAC4jx_dWPx-06Ed8wEwe7CqvoukqgV_NmA";

async function updateToken() {
  console.log("Updating token in Firestore...");
  try {
    const tokensRef = collection(db, 'tokens');
    const docRef = await addDoc(tokensRef, {
      value: NEW_TOKEN,
      updated_at: serverTimestamp()
    });
    console.log(`✅ Token updated successfully! New document ID: ${docRef.id}`);
    process.exit(0);
  } catch (err) {
    console.error("❌ Error updating token:", err);
    process.exit(1);
  }
}

updateToken();
