import { initializeApp } from "firebase/app";
import { getFirestore, doc, getDoc, collection, query, orderBy, limit, getDocs } from "firebase/firestore";
import fs from 'fs';
import path from 'path';

// Parse .env manually
try {
  const envContent = fs.readFileSync(path.resolve('.env'), 'utf8');
  envContent.split('\n').forEach(line => {
    const match = line.match(/^\s*([\w.-]+)\s*=\s*(.*)?\s*$/);
    if (match) {
      const key = match[1];
      let value = match[2] || '';
      if (value.startsWith('"') && value.endsWith('"')) {
        value = value.substring(1, value.length - 1);
      } else if (value.startsWith("'") && value.endsWith("'")) {
        value = value.substring(1, value.length - 1);
      }
      process.env[key] = value;
    }
  });
} catch (e) {
  console.error("Could not load .env file", e);
}

const firebaseConfig = {
  apiKey: process.env.VITE_FIREBASE_API_KEY,
  authDomain: process.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: process.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: process.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.VITE_FIREBASE_APP_ID
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

async function diagnose() {
  console.log("=== DIAGNOSING FIRESTORE STATE ===");
  
  // 1. Fetch settings
  try {
    const settingsRef = doc(db, 'settings', 'general_settings');
    const settingsSnap = await getDoc(settingsRef);
    if (settingsSnap.exists()) {
      console.log("\n--- GENERAL SETTINGS ---");
      const data = settingsSnap.data();
      console.log("Active Gateway:", data.active_gateway);
      console.log("FastLipa Token length:", data.fastlipa_token ? data.fastlipa_token.length : 0);
      console.log("PalmPesa Token length:", data.palmpesa_token ? data.palmpesa_token.length : 0);
      console.log("PalmPesa User ID:", data.palmpesa_user_id);
    } else {
      console.log("General settings document not found!");
    }
  } catch (err) {
    console.error("Error reading settings:", err);
  }

  // 2. Fetch plans
  try {
    const plansCol = collection(db, 'plans');
    const snap = await getDocs(plansCol);
    console.log("\n--- SUBSCRIPTION PLANS ---");
    snap.forEach((doc) => {
      const data = doc.data();
      console.log(`\nPlan ID: ${doc.id}`);
      console.log("Name:", data.name);
      console.log("Plan Key:", data.plan_key);
      console.log("Amount:", data.amount);
      console.log("Duration Days:", data.duration_days);
      console.log("Active:", data.active);
    });
  } catch (err) {
    console.error("Error reading plans:", err);
  }
  
  process.exit(0);
}

diagnose();
